## Information about assets directory

This folder contains all assets needed in our application. \n
To load assets into Visual Studio project, copy this folder with same name as Assets to location \n
where executable from Visual Studio project is created. \n